---
create_time: 1582345838
update_time: 1582345838
title: 【洛谷日报】谈谈字符串与字符数组
board: 1
tag:
- 2
---

- $size$：`size`。
- $\mathit{size}$：`\mathit{size}`。