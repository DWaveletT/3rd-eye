---
create_time: 1657082119
update_time: 1657082119
title: 占位 1
board: 1
tag:
- 1
extension:
  problem:
    id: P2333
    type: P
    title: '[SCOI2006] 一孔之见'
    difficulty: 9
    submitted: false
    accepted: false
---

```cpp
asd
asd
a

	asdasd
asdasd	asd
```